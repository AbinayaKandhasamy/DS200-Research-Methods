# This python script generates a scatter plot showing
# Exports Vs Imports per financial year during 1949 to 2012

import pandas as pd
import matplotlib.pyplot as plt

#create dataframe
df=pd.read_csv("scatter_plot_data.csv", header=None, names=['col1', 'col2'])

#plot scatter with first column as x values and second column as y values
plt.scatter(df['col1'],df['col2'],color='#dd12dd',label="scatter-label")

#specifying labels
plt.xlabel("Exports in Rs. 1000 Cr")
plt.ylabel("Imports in Rs. 1000 Cr")
plt.title("Exports Vs Imports per financial year during 1949 to 2012")

plt.show()