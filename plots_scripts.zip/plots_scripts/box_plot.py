# This python script generates a box plot showing
# attendance of members in Loksabha-5-session-15

import pandas as pd
import matplotlib.pyplot as plt

#create dataframe from csv
df=pd.read_csv("box_plot_data.csv", header=None, names=['col1'])
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
plotMap.append(df['col1'].dropna().tolist())

#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1],["BoxPlot1"])
plt.ylabel("No of days present")
plt.title("Distribution of attendance of members in Loksabha-5-session-15")

plt.show()