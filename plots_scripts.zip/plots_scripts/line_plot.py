# This python script generates a line plot showing
# Proportion of Urban population in Total population

import pandas as pd
import matplotlib.pyplot as plt

#create dataframe
df=pd.read_csv('line_plot_data.csv', header=None, names=['col1', 'col2'])

#plot line plot with first column of dataframe as x values and second column as y values
plt.plot(df['col1'],df['col2'],color='#dd12dd',label="line-label")
# plt.scatter(Mem['col3'],Mem['col4'],color='#caabdd',label="Hop6")

#specifying labels
plt.xlabel("Year")
plt.ylabel("% of Urban Population")
plt.title("Proportion of Urban population and Total population")
#enable legend
plt.show()